package com.example.chapter1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
