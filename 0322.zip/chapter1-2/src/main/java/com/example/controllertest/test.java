package com.example.controllertest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class test {
	@RequestMapping("/home/menu")
	@ResponseBody()
	public String shoMain() {
		return "오늘의 메뉴는 참스테이크입니다.";
	}
}
