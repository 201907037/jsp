package com.example.chapter12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter12Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter12Application.class, args);
		/*
		 * SpringApplication saApp = new SpringApplication(Chapter12Application.class);
		 * saApp.setWebApplicationType(WebApplicationType.SERVLET); saApp.run(args);
		 */
		
	}
	//maven해석 방식 <-> gradle
	//application.properties에서 설정 변경 ex)포트 번호 ...
	//ctrl+shift+o->클래스 자동 임포트
	//컨테이너=서버
	//src/main/java/com.example....->루트패키지
}
