package com.rubypaper;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
/*@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor*/
@Data
public class test {
	int no; 
	String title;
	String wirter;
	String content;
	Date date;
	int cnt;
}
