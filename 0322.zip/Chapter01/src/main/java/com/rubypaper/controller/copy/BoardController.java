package com.rubypaper.controller.copy;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rubypaper.test.BoardVO;

@Controller
public class BoardController {
	
	@RequestMapping("/board")
	@ResponseBody
	public BoardVO board() { //제이슨 파일
		BoardVO board = new BoardVO();
		board.setNo(1);
		board.setTitle("건의 사항");
		board.setWirter("kim");
		board.setContent("밥 많이 주세요");
		board.setDate(new Date());
		board.setCnt(1);
		return board;
	}
	
	@RequestMapping("/boardlist")
	@ResponseBody
	public List<BoardVO> boardlist() { 
		List<BoardVO> boardlist = new ArrayList<BoardVO>();
		for(int i=0;i<5;i++) {
			BoardVO board = new BoardVO();
			board.setNo(i);
			board.setTitle("건의 사항");
			board.setWirter("kim");
			board.setContent("밥 많이 주세요");
			board.setDate(new Date());
			board.setCnt(i);
			boardlist.add(board);
		}
		return boardlist;
	}
	
	public BoardController() {
		// TODO Auto-generated constructor stub
		System.out.println("=====BoardController=====");
	}
	@RequestMapping("/main")
	@ResponseBody
	public String name() {
		String result ="여러분 반가워요";
		return result;
	}
	@RequestMapping(value="/user/main",method=RequestMethod.GET)
	@ResponseBody
	public String showMain() {
		return "유한대학교";
	}
	@RequestMapping("/girl")
	public @ResponseBody String girl() {
		return "girl";
	}
	@RequestMapping("/boy")
	public @ResponseBody String boy(String name) {
		return "남자친구"+name;
	}
	@RequestMapping("/gift")
	public @ResponseBody String gift(String _gift) {
		return "받고 싶은 선물은"+_gift;
	}
	
}
