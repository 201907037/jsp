package com.rubypaper.test;

import java.util.Date;

public class BoardVO {
	
	public BoardVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	int no; //java private default이다
	String title;
	String wirter;
	String content;
	Date date;
	int cnt;
	
	public BoardVO(int no, String title, String wirter, String content, Date date, int cnt) {
		super();
		this.no = no;
		this.title = title;
		this.wirter = wirter;
		this.content = content;
		this.date = date;
		this.cnt = cnt;
	}
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWirter() {
		return wirter;
	}
	public void setWirter(String wirter) {
		this.wirter = wirter;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}

	@Override
	public String toString() {
		return "BoardVO [no=" + no + ", title=" + title + ", wirter=" + wirter + ", content=" + content + ", date="
				+ date + ", cnt=" + cnt + "]";
	}
}
