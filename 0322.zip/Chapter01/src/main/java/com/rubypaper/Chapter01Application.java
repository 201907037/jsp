package com.rubypaper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter01Application {

	public static void main(String[] args) {
		//SpringApplication.run(Chapter01Application.class, args);
		//밑에 2줄(application 생성 및 application.run)을 압축한 것이 위에 한줄
		SpringApplication application = new SpringApplication(
				Chapter01Application.class);
		//웹서버를 실행하지않고 자바처럼 콘솔에 출력하겠다는 코드->NONE
		//application.setWebApplicationType(WebApplicationType.NONE);
		//웹서버를 실행하겠다는 코드->SERVLET
		application.setWebApplicationType(WebApplicationType.SERVLET);//웹으로 할지 콘솔로 할지 결정하는 코드
		application.run(args);
	}

}
