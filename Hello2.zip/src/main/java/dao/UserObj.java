package dao;

public class UserObj {
	private String id, name, password,ts;
	
	public UserObj(String id, String name,String password, String ts) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.ts = ts;
	}
	
	public String getId() { return this.id; }
	public String getName() { return this.name; }
	public String getPass() { return this.password;}
	public String getTs() { return this.ts; }
}
